﻿namespace practica3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lanzar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Lanzar
            // 
            this.Lanzar.Location = new System.Drawing.Point(262, 119);
            this.Lanzar.Name = "Lanzar";
            this.Lanzar.Size = new System.Drawing.Size(75, 50);
            this.Lanzar.TabIndex = 0;
            this.Lanzar.Text = "lanzar";
            this.Lanzar.UseVisualStyleBackColor = true;
            this.Lanzar.Click += new System.EventHandler(this.Lanzar_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Lanzar);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Lanzar;
    }
}